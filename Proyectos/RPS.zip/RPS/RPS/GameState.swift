//
//  GameState.swift
//  RPS
//
//  Created by Guest User on 25/9/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import Foundation

enum GameState{
    case start, win, lose, draw
}
